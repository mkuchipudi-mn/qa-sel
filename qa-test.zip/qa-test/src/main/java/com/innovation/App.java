package com.innovation;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class App {

  public static void main(String[] args) throws Exception {
    System.setProperty("webdriver.chrome.driver",
        "D:\\KMK\\innovation\\qa-test\\src\\main\\resources\\chromedriver.exe");
    DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
    desiredCapabilities.setPlatform(Platform.ANY);
    desiredCapabilities.setBrowserName("chrome");
    ChromeOptions opt = new ChromeOptions();
    opt.merge(desiredCapabilities);
    while (true) {
      WebDriver driver = new ChromeDriver(opt);
      driver.manage().window().maximize();
      driver.manage().deleteAllCookies();
      driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
      driver.get("https://www.google.com/");
      driver.findElement(By.name("q")).sendKeys("YouTube");
      WebElement searchIcon = driver.findElement(By.name("btnK"));
      searchIcon.click();
      driver.close();
      Thread.sleep(5000);
    }
  }
}
